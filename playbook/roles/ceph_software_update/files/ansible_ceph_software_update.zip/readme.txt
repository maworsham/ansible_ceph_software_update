Something about our environment:
* We're using Red Hat Ansible Automation Platform and RHEL 8/9 for the hosts.
* We get a mail when the Job fails.
* Deployed Ceph via Cephadm.
* Cephadm hosts are hosts with the following labels and services: mon,_admin,mgr,alertmanager,prometheus,grafana.
* The load balancer is broken in our setting; there are issues with TLS 1.3. So we have a little workaround to call the cephadm/mgr nodes directly. Waiting for 18.2.3 to enable TLS 1.2 on the mgr.
* Roles is empty in this export.

This Playbook works for us, make adjustments to get it working for yourself :-)
